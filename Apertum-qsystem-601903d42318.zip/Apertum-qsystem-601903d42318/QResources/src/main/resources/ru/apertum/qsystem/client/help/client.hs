<?xml version='1.0' encoding='UTF-8' ?>
<!DOCTYPE helpset
  PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 1.0//EN"
         "helpset_1_0.dtd">

<helpset version="1.0">
  <title>Помощь. Рабочее место системы упревления клиетами.</title>
  <maps>
    <mapref location="client_map.jhm"/>
    <homeID>overview</homeID>
  </maps>
  <view>
    <name>Содержание</name>
    <label>Содержание</label>
    <type>javax.help.TOCView</type>
    <data>client_toc.xml</data>
  </view>
  <view>
    <name>Поиск</name>
    <label>Поиск</label>
    <type>javax.help.IndexView</type>
    <data>client_index.xml</data>
  </view>
</helpset>