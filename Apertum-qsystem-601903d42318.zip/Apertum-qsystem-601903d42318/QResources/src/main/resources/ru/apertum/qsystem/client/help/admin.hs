<?xml version='1.0' encoding='UTF-8' ?>
<!DOCTYPE helpset
  PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 1.0//EN"
         "helpset_1_0.dtd">

<helpset version="1.0">
  <title>Помощь. Мониторинг и конфигурирование системы.</title>
  <maps>
    <mapref location="admin_map.jhm"/>
    <homeID>overview</homeID>
  </maps>
  <view>
    <name>Содержание</name>
    <label>Содержание</label>
    <type>javax.help.TOCView</type>
    <data>admin_toc.xml</data>
  </view>
  <view>
    <name>Поиск</name>
    <label>Поиск</label>
    <type>javax.help.IndexView</type>
    <data>admin_index.xml</data>
  </view>
</helpset>