﻿#!/bin/sh
java -cp install.jar com.izforge.izpack.installer.bootstrap.Installer

