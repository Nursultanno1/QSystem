#!/bin/sh
java -cp dist/QSystem.jar ru.apertum.qsystem.client.forms.FReception -sport $serverPort -cport $clientPort -s $serverAdress