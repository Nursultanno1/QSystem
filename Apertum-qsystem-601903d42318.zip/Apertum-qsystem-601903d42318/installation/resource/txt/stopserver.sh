#!/bin/sh
java -cp dist/QSystem.jar ru.apertum.qsystem.server.Exit