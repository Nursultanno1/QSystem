#!/bin/sh
java -cp dist/QSystem.jar ru.apertum.qsystem.client.TabloRedactor -tcfg config/clientboard.xml