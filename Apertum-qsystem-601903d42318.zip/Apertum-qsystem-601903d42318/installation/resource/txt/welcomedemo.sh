#!/bin/sh
java -cp dist/QSystem.jar ru.apertum.qsystem.client.forms.FWelcome --debug -sport $serverPort -cport $clientPort -s $serverAdress