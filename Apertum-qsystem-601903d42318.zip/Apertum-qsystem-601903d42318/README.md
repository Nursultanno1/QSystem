QSYSTEM
Official site

Queue automation system "QSystem by Apertum"
QMS QSystem is software product which main purpose is customer flow management. There are a lot of benefits of using Qsystem in various commercial and state organizations. QMS Qsystem brings controlled and fair waiting process. When everything is planned organization works more efficiently and customers are more satisfied. Read More

Система управления электронными очередями
Предлагаемый Проект - это современный комплекс свободного программного обеспечения и аппаратных средств, позволяющих обеспечить комфортное оказание услуг и оптимизировать управление очередями посетителей коммерческих и государственных учреждений. Подробнее

QSystem sistema de gestión de colas electrónico
Propuesta de proyecto - un moderno complejo de software y hardware libre para una confortable y servicios y la optimización de colas visitantes agencias comerciales y gubernamentales. leer más